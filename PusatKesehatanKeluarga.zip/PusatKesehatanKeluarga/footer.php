<?php
// display
$smarty->assign('year', $year);
$smarty->display($page);
?>