<?php
$hostName	= "localhost";
$username	= "root";
$password	= "";
$dbName		= "dbwarga";

$connect = mysqli_connect($hostName,$username,$password,$dbName);
?>