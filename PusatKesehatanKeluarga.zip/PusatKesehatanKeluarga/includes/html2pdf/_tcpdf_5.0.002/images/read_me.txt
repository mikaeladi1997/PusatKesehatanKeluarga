download the TCPDF package to have this resources.

it has been removed because of the size of the package of HTML2PDF... 